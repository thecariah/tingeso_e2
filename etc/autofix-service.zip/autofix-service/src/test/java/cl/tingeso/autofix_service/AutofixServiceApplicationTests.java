package cl.tingeso.autofix_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutofixServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
