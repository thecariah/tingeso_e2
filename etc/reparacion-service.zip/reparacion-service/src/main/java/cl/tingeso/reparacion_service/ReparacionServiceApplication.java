package cl.tingeso.reparacion_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReparacionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReparacionServiceApplication.class, args);
	}

}
